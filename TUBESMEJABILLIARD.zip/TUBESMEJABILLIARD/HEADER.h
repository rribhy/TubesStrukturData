#ifndef TUBESSTDKERETA_H_INCLUDED
#define TUBESSTDKERETA_H_INCLUDED
#include <iostream>

using namespace std;

#define first(L) L.first
#define info(P) P->info
#define next(P) P->next
#define nextCustomer(P) P->nextCustomer
#define nextMain(P) P-> nextMain

//----------INFOTYPE----------//
struct infotypeBilliard{
    string merk;
    string status;
    string namaCust;
    int noMeja;
    int lamaPenyewaan;
};
struct infotypeCustomer{
    string nama;
    string member;
    string gender;
    int IDCust;
    int umurCust;
};

typedef struct elmListBilliard *adrBilliard;
typedef struct elmListCustomer *adrCustomer;
typedef struct elmListMain *adrMain;

//----------ADT CUSTOMER----------//
struct elmListCustomer {
    infotypeCustomer info;
    adrCustomer next;
};
struct ListCustomer {
    adrCustomer first;
};

//----------ADT MAIN----------//
struct elmListMain {
    adrCustomer nextCustomer;
    adrMain next;
};
struct ListMain {
    adrMain first;
};

//----------ADT BILLIARD----------//
struct elmListBilliard {
    infotypeBilliard info;
    adrBilliard next;
    ListMain nextMain;
};
struct ListBilliard {
    adrBilliard first;
};

//----------FUNCTION CREATE LIST----------//
void createListBilliard(ListBilliard &LBilliard);
void createListCustomer(ListCustomer &LCustomer);

//----------FUNCTION ALLOCATE----------//
adrBilliard allocateBilliard(infotypeBilliard xBilliard);
adrCustomer allocateCustomer(infotypeCustomer xCustomer);
adrMain allocateMain(adrCustomer Q);

//----------FUNCTION INSERT----------//
void insertLastBilliard(ListBilliard &LBilliard, adrBilliard P);
void insertLastCustomer(ListCustomer &LCustomer, adrCustomer P);
void insertMain(ListBilliard &LBilliard, ListCustomer &LCustomer, adrBilliard P, string namaCustomer, adrMain L);

//----------FUNCTION SHOW INFO----------//
void showInfoBilliard(ListBilliard LBilliard);
void showInfoCustomer(ListCustomer LCustomer);

//----------FUNCTION DELETE----------//
void deleteDataBilliard(ListBilliard &LBilliard, int nomorMeja);
void deleteDataCustomer(ListCustomer &LCustomer, string namaCust);
void deleteDataMain(ListBilliard &LBilliard, ListCustomer &LCustomer, string namaCustomer, int noMeja, adrMain L);

//----------FUNCTION SEARCHING----------//
adrBilliard searchingDataBilliard(ListBilliard &LBilliard, int nomorMeja);
adrCustomer searchingDataCustomer(ListCustomer &LCustomer, string namaCustomer);
adrMain searchingDataMain(ListBilliard &LBilliard, ListCustomer &LCustomer, string namaCust, int noMeja);

//----------FUNCTION SHOW FUNGSIONALITAS----------//
int countCustomerInOneTable(ListBilliard LBilliard, int nomorMeja, adrBilliard P); //menghitung customer yang memakai 1 meja
void showInfoOneTable(ListBilliard LBilliar, int nomorMeja); //menampilkan customer yang memakai 1 meja
void showInfoUsedCustomer(ListBilliard LBilliard);//meja yang disewa 1 customer
void showInfoUnusedTable(ListBilliard LBilliard); //menampilkan meja yang tidak dipakai
void showAgeCustomer(ListCustomer LCustomer);//nampilin customer berdasarkan usia yang diinputkan
adrCustomer searchingDataCustomerIDCustomer(ListCustomer &LCustomer, int IDCustomer);

//----------FUNCTION MENU----------//
void menu();
#endif // TUBESSTDKERETA_H_INCLUDED
