#include "HEADER.h"

int main()
{
    int pilihanMenu, pilihanSubMenu, jawabanNomorMeja, jawabanLamaPenyewaan, jumlahPesanSatuMeja;
    string jawabanMenu, namaCustomer;
    infotypeBilliard jawabanBilliard;
    infotypeCustomer jawabanCustomer;
    adrBilliard A, B, C, D;
    adrCustomer P, Q, R, S;
    adrMain L, M, N, O;
    ListBilliard LBilliard;
    ListCustomer LCustomer;

    pilihanMenu = 1;
    createListBilliard(LBilliard);
    createListCustomer(LCustomer);

    jawabanBilliard.merk = "Yupiter";
    jawabanBilliard.status = "Unused";
    jawabanBilliard.noMeja = 101;
    jawabanBilliard.namaCust = "-";
    jawabanBilliard.lamaPenyewaan = 0;
    A = allocateBilliard(jawabanBilliard);
    insertLastBilliard(LBilliard, A);

    jawabanBilliard.merk = "Plato";
    jawabanBilliard.status = "Unused";
    jawabanBilliard.noMeja = 102;
    jawabanBilliard.namaCust = "-";
    jawabanBilliard.lamaPenyewaan = 0;
    B = allocateBilliard(jawabanBilliard);
    insertLastBilliard(LBilliard, B);

    jawabanCustomer.nama = "Ridho";
    jawabanCustomer.member = "Platinum";
    jawabanCustomer.gender = "L";
    jawabanCustomer.IDCust = 1301223456;
    jawabanCustomer.umurCust = 19;
    P = allocateCustomer(jawabanCustomer);
    insertLastCustomer(LCustomer, P);

    jawabanCustomer.nama = "Rijal";
    jawabanCustomer.member = "Classic";
    jawabanCustomer.gender = "P";
    jawabanCustomer.IDCust = 1301223257;
    jawabanCustomer.umurCust = 16;
    Q = allocateCustomer(jawabanCustomer);
    insertLastCustomer(LCustomer, Q);

    while (pilihanMenu != 0 && jawabanMenu != "N"){
        menu();
        cin >> pilihanMenu;
        cout << endl;
        if (pilihanMenu == 1){
            cout << "============SUB MENU============" << endl;
            cout << "1. Menambah meja billiard." << endl;
            cout << "2. Daftar member customer." << endl;
            cout << "3. Booking meja billiard." << endl;
            cout << "Masukan pilihan: ";
            cin >> pilihanSubMenu;
            if (pilihanSubMenu == 1){
                cout << "Masukan merk meja billiard (Murray/Plato/Yupiter): ";
                cin >> jawabanBilliard.merk;
                cout << "Masukan status meja (Use/Unused): ";
                cin >> jawabanBilliard.status;
                cout << "Masukan nomor meja (101/102/103/...): ";
                cin >> jawabanBilliard.noMeja;
                while (jawabanBilliard.noMeja == 101 || jawabanBilliard.noMeja == 102){
                    cout << "Nomor meja sudah terpakai. Masukan kembali nomor meja yang baru: ";
                    cin >> jawabanBilliard.noMeja;
                }
                cout << "Masukan nama customer yang sedang memesan: ";
                cin >> jawabanBilliard.namaCust;
                cout << "Masukan lama penyewaan meja (0/60/120/180/...): ";
                cin >> jawabanBilliard.lamaPenyewaan;
                C = allocateBilliard(jawabanBilliard);
                insertLastBilliard(LBilliard, C);
                cout << endl;
            } else if (pilihanSubMenu == 2){
                cout << "Masukan nama customer: ";
                cin >> jawabanCustomer.nama;
                cout << "Masukan meber customer (Classic/Silver/Gold/Platinum): ";
                cin >> jawabanCustomer.member;
                cout << "Masukan gender customer (P/L): ";
                cin >> jawabanCustomer.gender;
                cout << "Masukan ID customer: ";
                cin >> jawabanCustomer.IDCust;
                cout << "Masukan umur customer: ";
                cin >> jawabanCustomer.umurCust;
                R = allocateCustomer(jawabanCustomer);
                insertLastCustomer(LCustomer, R);
                cout << endl;
            } else if (pilihanSubMenu == 3){
                cout << "Masukan nomor meja yang ingin dibooking: ";
                cin >> jawabanNomorMeja;
                D = searchingDataBilliard(LBilliard, jawabanNomorMeja);
                while (D == NULL){
                    cout << "Meja tidak tersedia, masukan kembali nomor meja yang ingin dibooking: ";
                    cin >> jawabanNomorMeja;
                    D = searchingDataBilliard(LBilliard, jawabanNomorMeja);
                }
                jumlahPesanSatuMeja = countCustomerInOneTable(LBilliard, jawabanNomorMeja, D);
                if (jumlahPesanSatuMeja > 5 || info(D).lamaPenyewaan >= 300){
                    cout << "Meja tidak bisa dibooking, sudah penuh." << endl;
                } else {
                    if (info(D).namaCust == "-"){
                        cout << "Masukan nama customer yang ingin booking meja billiard: ";
                        cin >> namaCustomer;
                        info(D).status = "Used";
                        info(D).namaCust = namaCustomer;
                        S = searchingDataCustomer(LCustomer, namaCustomer);
                        if (S == NULL){
                            cout << "Anda belum menjadi member." << endl;
                            cout << "Masukan nama customer: ";
                            cin >> jawabanCustomer.nama;
                            cout << "Masukan status member customer (Classic/Silver/Gold/Platinum): ";
                            cin >> jawabanCustomer.member;
                            cout << "Masukan gender customer (P/L): ";
                            cin >> jawabanCustomer.gender;
                            cout << "Masukan ID customer: ";
                            cin >> jawabanCustomer.IDCust;
                            cout << "Masukan umur customer: ";
                            cin >> jawabanCustomer.umurCust;
                            S = allocateCustomer(jawabanCustomer);
                            insertLastCustomer(LCustomer, S);
                        }
                        cout << "Masukan lama penyewaan (60/120/180/...): ";
                        cin >> jawabanLamaPenyewaan;
                        while (jawabanLamaPenyewaan > 301){
                            cout << "Waktu penyewaan terlalu lama. Kurangi waktu penyewaannya, anda hanya bisa mememsan meja selama 5 jam sehari: ";
                            cin >> jawabanLamaPenyewaan;
                        }
                        info(D).lamaPenyewaan = info(D).lamaPenyewaan + jawabanLamaPenyewaan;
                        if (info(D).lamaPenyewaan >= 300){
                            info(D).lamaPenyewaan = 300;
                        }
                        L = allocateMain(S);
                        insertMain(LBilliard, LCustomer, D, namaCustomer, L);
                    } else if (info(D).namaCust != "-"){
                        cout << "Masukan nama customer yang ingin booking meja billiard: ";
                        cin >> namaCustomer;
                        S = searchingDataCustomer(LCustomer, namaCustomer);
                        if (S == NULL){
                            cout << "Anda belum menjadi member." << endl;
                            cout << "Masukan nama customer: ";
                            cin >> jawabanCustomer.nama;
                            cout << "Masukan status member customer (Classic/Silver/Gold/Platinum): ";
                            cin >> jawabanCustomer.member;
                            cout << "Masukan gender customer (P/L): ";
                            cin >> jawabanCustomer.gender;
                            cout << "Masukan ID customer: ";
                            cin >> jawabanCustomer.IDCust;
                            cout << "Masukan umur customer: ";
                            cin >> jawabanCustomer.umurCust;
                            S = allocateCustomer(jawabanCustomer);
                            insertLastCustomer(LCustomer, S);
                        }
                        L = allocateMain(S);
                        insertMain(LBilliard, LCustomer, D, namaCustomer, L);
                    }
                }
                cout << endl;
            }
        } else if (pilihanMenu == 2){
            cout << "============SUB MENU============" << endl;
            cout << "1. Mencari data meja billiard." << endl;
            cout << "2. Mencari data customer." << endl;
            cout << "Masukan pilihan: ";
            cin >> pilihanSubMenu;
            if (pilihanSubMenu == 1){
                cout << "Masukan nomor meja: " << endl;
                cin >> jawabanNomorMeja;
                adrBilliard E = searchingDataBilliard(LBilliard, jawabanNomorMeja);
                cout << "Merk meja: " << info(E).merk << ". Status meja: " << info(E).status << ". Nama customer: " << info(E).namaCust << ". Nomor meja: " << info(E).noMeja << ". Lama penyewaan: " << info(E).lamaPenyewaan << endl;
            }
            cout << endl;
        } else if (pilihanMenu == 3){
            cout << "============SUB MENU============" << endl;
            cout << "1. Delete data meja billiard." << endl;
            cout << "2. Delete data customer." << endl;
            cout << "Masukan pilihan: ";
            cin >> pilihanSubMenu;
            if (pilihanSubMenu == 1){
                cout << "Masukan nomor meja yang ingin dihapus: ";
                cin >> jawabanNomorMeja;
                deleteDataBilliard(LBilliard, jawabanNomorMeja);
            } else if (pilihanSubMenu == 2){
                cout <<"Apakah customer sedang bermain? Jika iya, masukan nomor meja yang sedang digunakan (jika tidak isi dengan '0'): ";
                int noMeja;
                cin >> noMeja;
                if (noMeja == 0){
                    cout << "Masukan nama customer yang ingin dihapus: ";
                    cin >> namaCustomer;
                    deleteDataCustomer(LCustomer, namaCustomer);
                    adrMain L;
                    deleteDataMain(LBilliard, LCustomer, namaCustomer, noMeja, L);
                } else {
                    cout << "Masukan nama customer yang ingin dihapus: ";
                    cin >> namaCustomer;
                    deleteDataCustomer(LCustomer, namaCustomer);
                    adrMain L;
                    deleteDataMain(LBilliard, LCustomer, namaCustomer, noMeja, L);
                }
            }
            cout << endl;
        } else if (pilihanMenu == 4){
            cout << "============SUB MENU============" << endl;
            cout << "1. Data meja billiard." << endl;
            cout << "2. Data seluruh customer." << endl;
            cout << "Masukan pilihan: ";
            cin >> pilihanSubMenu;
            if (pilihanSubMenu == 1){
                showInfoBilliard(LBilliard);
            } else if (pilihanSubMenu == 2){
                showInfoCustomer(LCustomer);
            }
            cout << endl;
        } else if (pilihanMenu == 5){
            cout << "============SUB MENU============" << endl;
            cout << "1. Mencari customer dengan ID customer." << endl;
            cout << "2. Menampilkan data meja yang sedang tidak terpakai." << endl;
            cout << "3. Menampilkan jumlah customer yang memakai meja." << endl;
            cout << "4. Menampilkan customer dengan usia tertentu." << endl;
            cout << "5. Menampilkan data meja yang sedang terpakai." << endl;
            cout << "6. Menampilkan data customer yang sedang memakai satu meja." << endl;
            cout << "Masukan pilihan: ";
            cin >> pilihanSubMenu;
            if (pilihanSubMenu == 1){
                cout << "Masukan ID customer yang ingin dicari: ";
                int jawabanIDCust;
                cin >> jawabanIDCust;
                adrCustomer O;
                O = searchingDataCustomerIDCustomer(LCustomer, jawabanIDCust);
                if (O != NULL){
                    cout << "Nama Customer: " << info(O).nama << ". Member Customer: " << info(O).member << ". Gender Customer: " << info(O).gender << ". Usia Customer: " << info(O).umurCust << ". ID Customer: " << info(O).IDCust << endl;
                } else {
                    cout << "Customer tidak bergabung kedalam member." << endl;
                }
            } else if (pilihanSubMenu == 2){
                showInfoUnusedTable(LBilliard);
            } else if (pilihanSubMenu == 3){
                adrBilliard P;
                int noMeja, jumlah;
                cout << "Masukan nomor meja yang ingin dihitung: ";
                cin >> noMeja;
                jumlahPesanSatuMeja = countCustomerInOneTable(LBilliard, noMeja, P);
                cout << "Jumlah customer yang memakai meja " << noMeja << " adalah: " << jumlahPesanSatuMeja << endl;
            } else if (pilihanSubMenu == 4){
                showAgeCustomer(LCustomer);
            } else if (pilihanSubMenu == 5){
                showInfoUsedCustomer(LBilliard);
            } else if (pilihanSubMenu == 6){
                cout << "Masukan nomor meja yang sedang ingin dicari: ";
                int noMeja;
                cin >> noMeja;
                showInfoOneTable(LBilliard, noMeja);
            }
        }
        cout << endl;
    }
}
