#include "HEADER.h"

//----------FUNCTION CREATE LIST----------//
void createListBilliard(ListBilliard &LBilliard){
    //membuat list billiard
    first(LBilliard) = NULL;
}
void createListCustomer(ListCustomer &LCustomer){
    //membuat list customer
    first(LCustomer) = NULL;
}

//----------FUNCTION ALLOCATE----------//
adrBilliard allocateBilliard(infotypeBilliard xBilliard){
    //membuat element billiard
    adrBilliard p = new elmListBilliard;
    info(p) = xBilliard;
    next(p) = NULL;
    first(nextMain(p)) = NULL;
    return p;
}
adrCustomer allocateCustomer(infotypeCustomer xCustomer){
    //membuat element customer
    adrCustomer p = new elmListCustomer;
    info(p) = xCustomer;
    next(p) = NULL;
    return p;
}
adrMain allocateMain(adrCustomer Q){
    //membuat element customer yang sedang bermain
    adrMain p = new elmListMain;
    nextCustomer(p) = Q;
    next(p) = NULL;
    return p;
}

//----------FUNCTION INSERT----------//
void insertLastBilliard(ListBilliard &LBilliard, adrBilliard P){
    //memasukan element baru kedalam list billiard
    if (first(LBilliard) == NULL){
        first(LBilliard) = P;
    } else {
        adrBilliard prec = first(LBilliard);
        while (next(prec) != NULL){
            prec = next(prec);
        }
        next(prec) = P;
    }
}
void insertLastCustomer(ListCustomer &LCustomer, adrCustomer P){
    //memasukan element baru kedalam list customer
    if (first(LCustomer) == NULL){
        first(LCustomer) = P;
    } else {
        adrCustomer prec = first(LCustomer);
        while (next(prec) != NULL){
            prec = next(prec);
        }
        next(prec) = P;
    }
}
void insertMain(ListBilliard &LBilliard, ListCustomer &LCustomer, adrBilliard P, string namaCustomer, adrMain L){
    //refrence data customer kedalam list billiard
    if (first(P->nextMain) == NULL){
        first(P->nextMain) = L;
    } else if (first(P->nextMain) != NULL){
        adrMain S = first(P->nextMain);
        if (next(S) == NULL){
            next(S) = L;
        } else {
            while (next(S) != NULL){
                S = next(S);

            }
            next(S) = L;
        }
    }
}

//----------FUNCTION SHOW INFO SELURUH DATA----------//
void showInfoBilliard(ListBilliard LBilliard){
    //menampilkan data seluruh meja
    int i = 1;
    adrBilliard P = first(LBilliard);
    if (P == NULL){
        cout << "Tidak ada meja billiard yang sedang beroperasi." << endl;
    } else {
        while (P != NULL){
            cout << i << ". Nomor meja: " << info(P).noMeja << ". Status meja: " << info(P).status << ". Merk meja: " << info(P).merk << ". Lama penyewaan meja: " << info(P).lamaPenyewaan << ". Nama customer yang memesan meja: " << info(P).namaCust << endl;
            i++;
            P = next(P);
        }
    }
}
void showInfoCustomer(ListCustomer LCustomer){
    //menampilkan data seluruh customer
    int i = 1;
    adrCustomer P = first(LCustomer);
    if (P == NULL){
        cout << "Tidak ada customer." << endl;
    } else {
        while (P != NULL){
            cout << i << ". ID customer: " << info(P).IDCust << ". Nama customer: " << info(P).nama << ". Umur customer: " << info(P).umurCust << ". Member customer " << info(P).member << ". Gender customer: " << info(P).gender << endl;
            i++;
            P = next(P);
        }
    }
}

//----------FUNCTION SEARCHING----------//
adrBilliard searchingDataBilliard(ListBilliard &LBilliard, int nomorMeja){
    //menampilkan address data yang dicari
    adrBilliard P = first(LBilliard);
    while (P != NULL){
        if (info(P).noMeja == nomorMeja){
            return P;
        }
        P = next(P);
    }
    return NULL;
}
adrCustomer searchingDataCustomer(ListCustomer &LCustomer, string namaCustomer){
    //menampilkan address data yang dicari
    adrCustomer P = first(LCustomer);
    while (P != NULL){
        if (info(P).nama == namaCustomer){
            return P;
        }
        P = next(P);
    }
    return NULL;
}
adrMain searchingDataMain(ListBilliard &LBilliard, ListCustomer &LCustomer, string namaCust, int noMeja){
    //menampilkan address data yang dicari
    adrBilliard P = first(LBilliard);
    while(P != NULL || info(P).noMeja != noMeja){
        P = next(P);
    }
    adrMain Q = first(P->nextMain);
    while (next(Q) != NULL || info(nextCustomer(Q)).nama != namaCust){
        Q = next(Q);
    }
    return Q;
}

//----------FUNCTION DELETE----------//
void deleteDataBilliard(ListBilliard &LBilliard, int nomorMeja){
    //menghapus data billiard berdasarkan nomor meja billiard
    adrBilliard P = first(LBilliard);
    adrBilliard Q = searchingDataBilliard(LBilliard, nomorMeja);
    if (P == NULL){
        //jika list kosong
        cout << "List kosong." << endl;
    } else if (P == Q){
        //delete first
        if (next(Q) == NULL){
           first(LBilliard)=NULL; //jika isi list ada satu element
        } else {
            P = next(Q); //jika isi list lebih dari satu element
            next(Q) = NULL;
            first(LBilliard) = P;
            delete Q;
        }
    } else if (next(Q) == NULL) {
        //delete last
        while (next(P) != Q){
            P = next(P);
        }
        next(P) = NULL;
        delete Q;
    } else {
        //delete after
        adrBilliard prec = first(LBilliard);
        while (next(prec) != Q){
            prec = next(prec);
        }
        next(prec) = next(Q);
        next(Q) = NULL;
        delete Q;
    }
}
void deleteDataCustomer(ListCustomer &LCustomer, string namaCustomer){
    //menghapus data customer berdasarkan nama customer
    adrCustomer P = first(LCustomer);
    adrCustomer Q = searchingDataCustomer(LCustomer, namaCustomer);
    if (P == NULL){
        //jika list kosong
        cout << "List kosong." << endl;
    } else if (P == Q){
        //delete first
        if (next(Q) == NULL){
            first(LCustomer)=NULL; //jika isi list ada satu element
        } else {
            P = next(Q); //jika isi list lebih dari satu element
            next(Q) = NULL;
            first(LCustomer) = P;
            //delete Q;
        }
    } else if (next(Q) == NULL) {
        //delete last
        while (next(P) != Q){
            P = next(P);
        }
        next(P) = NULL;
        //delete Q;
    } else {
        //delete after
        adrCustomer prec = first(LCustomer);
        while (next(prec) != Q){
            prec = next(prec);
        }
        next(prec) = next(Q);
        next(Q) = NULL;
        //delete Q;
    }
}
void deleteDataMain(ListBilliard &LBilliard, ListCustomer &LCustomer, string namaCustomer, int noMeja, adrMain L){
    //menghapus data customer yang sedang bermain
    adrMain R = searchingDataMain(LBilliard, LCustomer, namaCustomer, noMeja);
    if (R == NULL){
        cout << "Data tidak tersedia." << endl;
    } else {
        nextCustomer(R) = NULL;
    }
}

//----------FUNCTION SHOW----------//
int countCustomerInOneTable(ListBilliard LBilliard, int nomorMeja, adrBilliard P){
    //menghitung customer yang memakai satu meja
    P = first(LBilliard);
    int jumlah = 0;
    while (info(P).noMeja != nomorMeja){
        P = next(P);
    }
    adrMain M = first(P->nextMain);
    while (M != NULL){
        jumlah++;
        M = next(M);
    }
    return jumlah;
}
void showInfoOneTable(ListBilliard LBilliar, int nomorMeja){
    //menampilkan data customer yang memesan satu meja
    adrBilliard P = searchingDataBilliard(LBilliar, nomorMeja);
    int jumlah = countCustomerInOneTable(LBilliar, nomorMeja, P);
    adrMain Q = first(P->nextMain);
    while (next(Q) != NULL){
        if (jumlah >= 1){
            cout << info(nextCustomer(Q)).IDCust << " " << info(nextCustomer(Q)).nama << " " << info(nextCustomer(Q)).umurCust << " " << info(nextCustomer(Q)).member << " " << info(nextCustomer(Q)).gender << endl;
        } else {
            cout << "Tidak ada penyewa.";
        }
        Q = next(Q);
    }
}
void showInfoUsedCustomer(ListBilliard LBilliard){
    //menampilkan data meja yang disewa customer
    adrBilliard P = first(LBilliard);
    adrMain M = first(P->nextMain);
    while (P != NULL){
        if (M == NULL){
            cout << "meja sedang tidak disewa." << endl;
        } else {
            cout << ". " << info(P).noMeja << " " << info(P).status << " " << info(P).merk << " " << info(P).lamaPenyewaan << endl;
        }
        P = next(P);
    }
}
void showInfoUnusedTable(ListBilliard LBilliard){
    //menampilkan data meja yang tidak dipesan/dipakai
    adrBilliard P = first(LBilliard);
    while (P != NULL){
        if (info(P).status == "Unused"){
            cout << info(P).noMeja << " " << info(P).status << " " << info(P).merk << endl;
        } else if (info(P).status == "Used") {
            cout << "Meja " << info(P).noMeja << " sedang dipakai." << endl;
        }
        P = next(P);
    }
}
void showAgeCustomer(ListCustomer LCustomer){
    //menampilkan data customer dengan umur tertentu
    adrCustomer P = first(LCustomer);
    while (P != NULL){
        if (info(P).umurCust >= 17){
            cout << info(P).IDCust << " " << info(P).nama << " " << info(P).umurCust << " " << info(P).member << " " << info(P).gender << endl;
        } else {
            cout << info(P).nama << " belum 17 tahun." << endl;
        }
        P = next(P);
    }
}
adrCustomer searchingDataCustomerIDCustomer(ListCustomer &LCustomer, int IDCustomer){
    //menampilkan address data yang dicari
    adrCustomer P = first(LCustomer);
    while (P != NULL){
        if (info(P).IDCust == IDCustomer){
            return P;
        }
        P = next(P);
    }
    return NULL;
}

//----------FUNCTION MENU----------//
void menu(){
    cout << "============MENU============" << endl;
    cout << "1. Menambahkan data." << endl;
    cout << "2. Mencari data." << endl;
    cout << "3. Menghapus data." << endl;
    cout << "4. Menampilkan data." << endl;
    cout << "5. Fungsionalitas." << endl;
    cout << "0. Exit." << endl;
    cout << "Masukan pilihan: ";
}
